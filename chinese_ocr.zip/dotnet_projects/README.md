# .Net版OcrLite范例

#### 介绍
本目录存放.Net相关demo项目
* OcrLiteOnnxCs项目是Windows平台C# WinForm范例
* OcrLiteOnnxVB项目是Windows平台VB.Net WinForm范例
