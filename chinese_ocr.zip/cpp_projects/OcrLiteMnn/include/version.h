#ifndef __OCR_VERSION_H__
#define __OCR_VERSION_H__

#define VERSION "1.5.1.20210128"

#endif //__OCR_VERSION_H__
