#!/bin/bash

echo Delete part img
rm -f *-part-*.jpg

echo Delete angle img
rm -f *-angle-*.jpg

echo Delete debug img
rm -f *-debug-*.jpg

echo Delete result img
rm -f *-result.jpg

echo Delete result txt
rm -f *-result.txt
