#ifndef __OCR_VERSION_H__
#define __OCR_VERSION_H__

#define VERSION "1.6.0.20211013"

#endif //__OCR_VERSION_H__
